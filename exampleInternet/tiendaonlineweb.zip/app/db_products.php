<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class db_products extends Model
{
    protected $table = 'tbl_publicaciones';
    public $timestamps = false;
}
