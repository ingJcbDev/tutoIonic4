<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class db_user_cliente extends Model
{
    protected $table = 'producto_ventas';
    public $timestamps = false;
}
