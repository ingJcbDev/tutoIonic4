<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class db_imagenes extends Model
{
    protected $table = 'tbl_publicacion_imagenes';
    public $timestamps = false;
}
